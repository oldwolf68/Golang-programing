package models

type Libro struct {
	ID               int
	TituloPrivado    string
	AutorPrivado     string
	CategoriaPrivado string
	AnioPrivado      int
}

// Getters
func (l Libro) Titulo() string    { return l.TituloPrivado }
func (l Libro) Autor() string     { return l.AutorPrivado }
func (l Libro) Categoria() string { return l.CategoriaPrivado }
func (l Libro) Anio() int         { return l.AnioPrivado }

// Setters
func (l *Libro) SetTitulo(t string)    { l.TituloPrivado = t }
func (l *Libro) SetAutor(a string)     { l.AutorPrivado = a }
func (l *Libro) SetCategoria(c string) { l.CategoriaPrivado = c }
func (l *Libro) SetAnio(a int)         { l.AnioPrivado = a }
