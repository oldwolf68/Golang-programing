// Proyecto: Sistema de Gestión de Libros Electrónicos
// Versión consola con conexión a base de datos MySQL
// Lenguaje: Go (Golang)
// Aplicando: Encapsulación, manejo de errores, interfaces y comentarios claros
// Autor: Carlos Maruri

package main

import (
	"bufio"
	"fmt"
	"libros-electronicos/bd"
	"libros-electronicos/controllers"
	"libros-electronicos/models"
	"os"
	"strconv"
	"strings"
)

// Interfaz ServicioLibro define las operaciones CRUD para libros
// Permite intercambiar la implementación (memoria o base de datos)
type ServicioLibro interface {
	Listar() []models.Libro
	Buscar(titulo, autor string) []models.Libro
	Agregar(libro models.Libro) error
	Actualizar(id int, libro models.Libro) error
	Eliminar(id int) error
}

func main() {
	bd.Conectar() // Establece conexión con la base de datos

	libros := &controllers.DBLibros{DB: bd.DB} // Instancia del controlador
	scanner := bufio.NewScanner(os.Stdin)      // Para capturar entrada desde consola

	for {
		// Menú principal
		fmt.Println("\n----- GESTIÓN DE LIBROS ELECTRÓNICOS -----")
		fmt.Println("1. Listar libros")
		fmt.Println("2. Buscar libros")
		fmt.Println("3. Registrar nuevo libro")
		fmt.Println("4. Editar libro")
		fmt.Println("5. Eliminar libro")
		fmt.Println("0. Salir")
		fmt.Print("Seleccione una opción: ")
		scanner.Scan()
		opcion := scanner.Text()

		switch opcion {
		case "1": // Listar libros existentes
			for _, l := range libros.Listar() {
				fmt.Printf("[%d] %s - %s (%s, %d)\n", l.ID, l.Titulo(), l.Autor(), l.Categoria(), l.Anio())
			}
		case "2": // Buscar libros por título y autor
			fmt.Print("Título: ")
			scanner.Scan()
			t := scanner.Text()
			fmt.Print("Autor: ")
			scanner.Scan()
			a := scanner.Text()
			res := libros.Buscar(t, a)
			if len(res) == 0 {
				fmt.Println("No se encontraron resultados.")
			} else {
				for _, l := range res {
					fmt.Printf("[%d] %s - %s (%s, %d)\n", l.ID, l.Titulo(), l.Autor(), l.Categoria(), l.Anio())
				}
			}
		case "3": // Registrar nuevo libro
			libro := leerLibro(scanner)
			if err := libros.Agregar(libro); err != nil {
				fmt.Println("Error:", err)
			} else {
				fmt.Println("Libro registrado correctamente.")
			}
		case "4": // Editar libro existente
			fmt.Print("ID a editar: ")
			scanner.Scan()
			id, _ := strconv.Atoi(scanner.Text())
			editado := leerLibro(scanner)
			if err := libros.Actualizar(id, editado); err != nil {
				fmt.Println("Error:", err)
			} else {
				fmt.Println("Libro actualizado.")
			}
		case "5": // Eliminar libro existente
			fmt.Print("ID a eliminar: ")
			scanner.Scan()
			id, _ := strconv.Atoi(scanner.Text())
			fmt.Print("¿Está seguro? (s/n): ")
			scanner.Scan()
			if strings.ToLower(scanner.Text()) == "s" {
				if err := libros.Eliminar(id); err != nil {
					fmt.Println("Error:", err)
				} else {
					fmt.Println("Libro eliminado.")
				}
			} else {
				fmt.Println("Operación cancelada.")
			}
		case "0":
			fmt.Println("Saliendo...")
			return
		default:
			fmt.Println("Opción inválida")
		}
	}
}

// leerLibro: Solicita los datos del libro y retorna una instancia del tipo Libro
func leerLibro(scanner *bufio.Scanner) models.Libro {
	fmt.Print("Título: ")
	scanner.Scan()
	titulo := scanner.Text()

	fmt.Print("Autor: ")
	scanner.Scan()
	autor := scanner.Text()

	fmt.Print("Categoría: ")
	scanner.Scan()
	categoria := scanner.Text()

	fmt.Print("Año: ")
	scanner.Scan()
	anio, _ := strconv.Atoi(scanner.Text())

	// Construye el libro usando setters (encapsulación)
	libro := models.Libro{}
	libro.SetTitulo(titulo)
	libro.SetAutor(autor)
	libro.SetCategoria(categoria)
	libro.SetAnio(anio)

	return libro
}
