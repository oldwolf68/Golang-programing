// controllers/libros.go

package controllers

import (
	"database/sql"
	"errors"
	"libros-electronicos/models"
)

type DBLibros struct {
	DB *sql.DB
}

// Listar devuelve todos los libros de la base de datos
func (d *DBLibros) Listar() []models.Libro {
	filas, err := d.DB.Query("SELECT id, titulo, autor, categoria, anio FROM libros")
	if err != nil {
		return []models.Libro{} // En caso de error, retorna slice vacío
	}
	defer filas.Close()

	var libros []models.Libro
	for filas.Next() {
		var l models.Libro
		var titulo, autor, categoria string
		var anio int
		if err := filas.Scan(&l.ID, &titulo, &autor, &categoria, &anio); err == nil {
			l.SetTitulo(titulo)
			l.SetAutor(autor)
			l.SetCategoria(categoria)
			l.SetAnio(anio)
			libros = append(libros, l)
		}
	}
	return libros
}

// Buscar busca libros por título y autor
func (d *DBLibros) Buscar(titulo, autor string) []models.Libro {
	consulta := `SELECT id, titulo, autor, categoria, anio FROM libros 
				WHERE LOWER(titulo) LIKE ? AND LOWER(autor) LIKE ?`
	filas, err := d.DB.Query(consulta, "%"+titulo+"%", "%"+autor+"%")
	if err != nil {
		return []models.Libro{}
	}
	defer filas.Close()

	var libros []models.Libro
	for filas.Next() {
		var l models.Libro
		var t, a, c string
		var anio int
		if err := filas.Scan(&l.ID, &t, &a, &c, &anio); err == nil {
			l.SetTitulo(t)
			l.SetAutor(a)
			l.SetCategoria(c)
			l.SetAnio(anio)
			libros = append(libros, l)
		}
	}
	return libros
}

// Agregar inserta un nuevo libro en la base de datos
func (d *DBLibros) Agregar(libro models.Libro) error {
	if libro.Titulo() == "" || libro.Autor() == "" {
		return errors.New("título y autor son obligatorios")
	}
	if libro.Anio() < 0 || libro.Anio() > 2100 {
		return errors.New("año inválido")
	}
	_, err := d.DB.Exec("INSERT INTO libros (titulo, autor, categoria, anio) VALUES (?, ?, ?, ?)",
		libro.Titulo(), libro.Autor(), libro.Categoria(), libro.Anio())
	return err
}

// Actualizar modifica un libro existente por su ID
func (d *DBLibros) Actualizar(id int, libro models.Libro) error {
	if libro.Titulo() == "" || libro.Autor() == "" {
		return errors.New("título y autor no pueden estar vacíos")
	}
	resultado, err := d.DB.Exec(`UPDATE libros SET titulo=?, autor=?, categoria=?, anio=? WHERE id=?`,
		libro.Titulo(), libro.Autor(), libro.Categoria(), libro.Anio(), id)
	if err != nil {
		return err
	}
	af, err := resultado.RowsAffected()
	if err != nil {
		return err
	}
	if af == 0 {
		return errors.New("libro no encontrado")
	}
	return nil
}

// Eliminar elimina un libro por ID
func (d *DBLibros) Eliminar(id int) error {
	resultado, err := d.DB.Exec("DELETE FROM libros WHERE id=?", id)
	if err != nil {
		return err
	}

	af, err := resultado.RowsAffected()
	if err != nil {
		return err
	}
	if af == 0 {
		return errors.New("libro no encontrado")
	}
	return nil
}
