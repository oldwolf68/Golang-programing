package main

import (
	"fmt"
	"net/http"

	"libros-electronicos/bd"
	"libros-electronicos/controllers"
	"libros-electronicos/web/rutas"
)

func main() {
	// Conexión a la base de datos
	bd.Conectar()

	// Crear servicio de libros
	servicio := &controllers.DBLibros{DB: bd.DB}

	// Registrar rutas con el servicio
	rutas.RegistrarRutas(servicio)

	fmt.Println("Servidor en http://localhost:8080")
	http.ListenAndServe(":8080", nil)
}
