// rutas.go
package rutas

import (
	"html/template"
	"log"
	"net/http"
	"strconv"

	"libros-electronicos/interfaces"
	"libros-electronicos/models"
)

var servicio interfaces.ServicioLibro
var baseTmpl = template.Must(template.ParseFiles(
	"vistas/templates/base.html",
	"vistas/templates/lista.html",
	"vistas/templates/form.html",
))

type PageData struct {
	Vista string
	Datos any
}

func RegistrarRutas(s interfaces.ServicioLibro) {
	servicio = s
	http.HandleFunc("/libros", listarHandler)
	http.HandleFunc("/libros/nuevo", nuevoHandler)
	http.HandleFunc("/libros/crear", crearHandler)
	http.HandleFunc("/libros/editar", editarHandler)
	http.HandleFunc("/libros/actualizar", actualizarHandler)
	http.HandleFunc("/libros/eliminar", eliminarHandler)
}

func listarHandler(w http.ResponseWriter, r *http.Request) {
	libros := servicio.Listar()
	err := baseTmpl.ExecuteTemplate(w, "base.html", PageData{
		Vista: "lista.html",
		Datos: libros,
	})
	if err != nil {
		log.Println("Error al renderizar lista:", err)
		http.Error(w, "Error al mostrar la lista", http.StatusInternalServerError)
	}
}

func nuevoHandler(w http.ResponseWriter, r *http.Request) {
	formData := struct {
		TituloForm string
		Accion     string
		Libro      models.Libro
	}{
		TituloForm: "Nuevo Libro",
		Accion:     "/libros/crear",
		Libro:      models.Libro{},
	}
	err := baseTmpl.ExecuteTemplate(w, "base.html", PageData{
		Vista: "form.html",
		Datos: formData,
	})
	if err != nil {
		log.Println("Error al renderizar formulario:", err)
		http.Error(w, "Error al mostrar formulario", http.StatusInternalServerError)
	}
}

func crearHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Redirect(w, r, "/libros", http.StatusSeeOther)
		return
	}

	libro := leerLibroForm(r)
	err := servicio.Agregar(libro)
	if err != nil {
		log.Println("Error al agregar libro:", err)
		http.Error(w, "Error al guardar el libro", http.StatusInternalServerError)
		return
	}

	http.Redirect(w, r, "/libros", http.StatusSeeOther)
}

func editarHandler(w http.ResponseWriter, r *http.Request) {
	id, _ := strconv.Atoi(r.URL.Query().Get("id"))
	lista := servicio.Listar()
	var encontrado models.Libro
	for _, l := range lista {
		if l.ID == id {
			encontrado = l
			break
		}
	}

	formData := struct {
		TituloForm string
		Accion     string
		Libro      models.Libro
	}{
		TituloForm: "Editar Libro",
		Accion:     "/libros/actualizar",
		Libro:      encontrado,
	}
	err := baseTmpl.ExecuteTemplate(w, "base.html", PageData{
		Vista: "form.html",
		Datos: formData,
	})
	if err != nil {
		log.Println("Error al renderizar edición:", err)
		http.Error(w, "Error al mostrar edición", http.StatusInternalServerError)
	}
}

func actualizarHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Redirect(w, r, "/libros", http.StatusSeeOther)
		return
	}

	id, _ := strconv.Atoi(r.FormValue("id"))
	libro := leerLibroForm(r)
	err := servicio.Actualizar(id, libro)
	if err != nil {
		log.Println("Error al actualizar libro:", err)
		http.Error(w, "Error al actualizar el libro", http.StatusInternalServerError)
		return
	}

	http.Redirect(w, r, "/libros", http.StatusSeeOther)
}

func eliminarHandler(w http.ResponseWriter, r *http.Request) {
	id, _ := strconv.Atoi(r.URL.Query().Get("id"))
	_ = servicio.Eliminar(id)
	http.Redirect(w, r, "/libros", http.StatusSeeOther)
}

func leerLibroForm(r *http.Request) models.Libro {
	anio, _ := strconv.Atoi(r.FormValue("anio"))
	return models.Libro{
		ID:        atoiSeguro(r.FormValue("id")),
		Titulo:    r.FormValue("titulo"),
		Autor:     r.FormValue("autor"),
		Categoria: r.FormValue("categoria"),
		Anio:      anio,
	}
}

func atoiSeguro(s string) int {
	i, _ := strconv.Atoi(s)
	return i
}
