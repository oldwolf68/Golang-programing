package models

type Libro struct {
	ID        int
	Titulo    string
	Autor     string
	Categoria string
	Anio      int
}
