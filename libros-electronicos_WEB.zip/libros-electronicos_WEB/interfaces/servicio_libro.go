package interfaces

import "libros-electronicos/models"

type ServicioLibro interface {
	Listar() []models.Libro
	Agregar(libro models.Libro) error
	Actualizar(id int, libro models.Libro) error
	Eliminar(id int) error
}
