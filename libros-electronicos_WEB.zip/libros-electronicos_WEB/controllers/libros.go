package controllers

import (
	"database/sql"
	"errors"
	"libros-electronicos/models"
)

type DBLibros struct {
	DB *sql.DB
}

func (d *DBLibros) Listar() []models.Libro {
	rows, err := d.DB.Query("SELECT id, titulo, autor, categoria, anio FROM libros")
	if err != nil {
		return nil
	}
	defer rows.Close()

	var libros []models.Libro
	for rows.Next() {
		var l models.Libro
		rows.Scan(&l.ID, &l.Titulo, &l.Autor, &l.Categoria, &l.Anio)
		libros = append(libros, l)
	}
	return libros
}

func (d *DBLibros) Agregar(libro models.Libro) error {
	_, err := d.DB.Exec("INSERT INTO libros(titulo, autor, categoria, anio) VALUES (?, ?, ?, ?)",
		libro.Titulo, libro.Autor, libro.Categoria, libro.Anio)
	return err
}

func (d *DBLibros) Actualizar(id int, libro models.Libro) error {
	res, err := d.DB.Exec("UPDATE libros SET titulo=?, autor=?, categoria=?, anio=? WHERE id=?",
		libro.Titulo, libro.Autor, libro.Categoria, libro.Anio, id)
	if err != nil {
		return err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return errors.New("no se actualizó ningún registro")
	}
	return nil
}

func (d *DBLibros) Eliminar(id int) error {
	_, err := d.DB.Exec("DELETE FROM libros WHERE id=?", id)
	return err
}

func (d *DBLibros) Buscar(titulo, autor string) []models.Libro {
	rows, err := d.DB.Query("SELECT id, titulo, autor, categoria, anio FROM libros WHERE titulo LIKE ? OR autor LIKE ?",
		"%"+titulo+"%", "%"+autor+"%")
	if err != nil {
		return nil
	}
	defer rows.Close()

	var encontrados []models.Libro
	for rows.Next() {
		var l models.Libro
		rows.Scan(&l.ID, &l.Titulo, &l.Autor, &l.Categoria, &l.Anio)
		encontrados = append(encontrados, l)
	}
	return encontrados
}
