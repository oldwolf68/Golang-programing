package controllers

import (
	"encoding/json"
	"log"
	"net/http"

	"libros-electronicos/models"
)

var libros = []models.Libro{
	{ID: 1, Titulo: "Go Básico", Autor: "Carlos", Categoria: "Programación", Anio: 2020},
	{ID: 2, Titulo: "Go Web", Autor: "Ana", Categoria: "Backend", Anio: 2022},
}

func APILibros(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	err := json.NewEncoder(w).Encode(libros)
	if err != nil {
		http.Error(w, "Error al generar JSON", http.StatusInternalServerError)
		log.Println("API Error:", err)
	}
}
